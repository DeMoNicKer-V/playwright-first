# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: contact.spec.ts >> Contact Page >> Should submit contact form successfully
- Location: tests/contact.spec.ts:12:7

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
Call log:
  - navigating to "/contact", waiting until "load"

```

# Test source

```ts
  1  | import { Locator, Page } from "@playwright/test";
  2  | 
  3  | class ContactPage {
  4  |   form: Locator;
  5  |   successMessage: Locator;
  6  |   constructor(private page: Page) {
  7  |     this.form = this.page.locator('form[id^="evf-form"]');
  8  |     this.successMessage = page.locator(
  9  |       "text=Thanks for contacting us! We will be in touch with you shortly",
  10 |     );
  11 |   }
  12 | 
  13 |   async navigate() {
> 14 |     await this.page.goto("/contact");
     |                     ^ Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
  15 |     await this.form.waitFor();
  16 |   }
  17 | 
  18 |   async fillForm(data: {
  19 |     name: string;
  20 |     email: string;
  21 |     phone: string;
  22 |     message: string;
  23 |   }) {
  24 |     await this.form.locator(".contact-name input").fill(data.name);
  25 |     await this.form.locator(".contact-email input").fill(data.email);
  26 |     await this.form.locator(".contact-phone input").fill(data.phone);
  27 |     await this.form.locator(".contact-message textarea").fill(data.message);
  28 |   }
  29 | 
  30 |   async submitForm() {
  31 |     await this.form.locator('button[type="submit"]').click();
  32 |   }
  33 | }
  34 | export default ContactPage;
  35 | 
```