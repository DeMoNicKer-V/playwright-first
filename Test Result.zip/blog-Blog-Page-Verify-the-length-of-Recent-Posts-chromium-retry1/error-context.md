# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: blog.spec.ts >> Blog Page >> Verify the length of Recent Posts
- Location: tests/blog.spec.ts:11:7

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
Call log:
  - navigating to "/blog", waiting until "load"

```

# Test source

```ts
  1  | import { Locator, Page } from "@playwright/test";
  2  | 
  3  | class BlogPage {
  4  |   readonly recentPosts: Locator;
  5  | 
  6  |   constructor(private page: Page) {
  7  |     this.recentPosts = page.locator(
  8  |       'aside#zak-secondary section[id^="recent-posts"] li',
  9  |     );
  10 |   }
  11 | 
  12 |   async navigate() {
> 13 |     await this.page.goto("/blog");
     |                     ^ Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
  14 |   }
  15 |   async getRecentPostsCount() {
  16 |     return await this.recentPosts.count();
  17 |   }
  18 | 
  19 |   async getRecentPostsTexts() {
  20 |     return await this.recentPosts.allTextContents();
  21 |   }
  22 | }
  23 | export default BlogPage;
  24 | 
```