# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account.spec.ts >> Account Page (Logged In) >> Access to the 'Orders'
- Location: tests/account.spec.ts:6:7

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
Call log:
  - navigating to "/my-account/orders", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | 
  3  | //test.describe("Account Page (Logged In)", () => {
  4  | //test by test (seq)
  5  | test.describe.serial("Account Page (Logged In)", () => {
  6  |   test("Access to the 'Orders'", async ({ page }) => {
> 7  |     await page.goto("/my-account/orders");
     |                ^ Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
  8  |     await expect(page).toHaveURL(/orders/);
  9  |   });
  10 | 
  11 |   test("Access to the 'Downloads'", async ({ page }) => {
  12 |     await page.goto("/my-account/downloads");
  13 |     await expect(page).toHaveURL(/downloads/);
  14 |   });
  15 | });
  16 | 
  17 | test.describe("Account Page (Not Looged In)", () => {
  18 |   // test.use({ storageState: { cookies: [], origins: [] } });
  19 |   test.use({ storageState: "notLoggedInState.json" });
  20 | 
  21 |   test("Verify the login and register is visible", async ({ page }) => {
  22 |     await page.goto("/my-account");
  23 |     await expect(page.locator('form[class*="login"]')).toBeVisible();
  24 |     await expect(page.locator('form[class*="register"]')).toBeVisible();
  25 |   });
  26 | });
  27 | 
```