# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: upload.spec.ts >> Upload File >> Should upload the test file (funnypic.jpg)
- Location: tests/upload.spec.ts:15:9

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
Call log:
  - navigating to "/cart", waiting until "load"

```

# Test source

```ts
  1  | import { Page } from "@playwright/test";
  2  | import UploadComponent from "./components/upload.component";
  3  | 
  4  | class CartPage {
  5  |   constructor(private page: Page) {}
  6  |   uploadComponent() {
  7  |     return new UploadComponent(this.page);
  8  |   }
  9  | 
  10 |   async navigate() {
> 11 |     await this.page.goto("/cart");
     |                     ^ Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
  12 |   }
  13 | }
  14 | 
  15 | export default CartPage;
  16 | 
```