# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: home.spec.ts >> Home Page >> Verify Home Link is enabled using Text and CSS Selectors
- Location: tests/home.spec.ts:20:7

# Error details

```
Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
Call log:
  - navigating to "/", waiting until "load"

```

# Test source

```ts
  1  | import { Locator, Page } from "@playwright/test";
  2  | 
  3  | class HomePage {
  4  |   headingText: Locator;
  5  |   homeText: Locator;
  6  |   searchIcon: Locator;
  7  |   navLinks: Locator;
  8  |   getStartedBtn: Locator;
  9  |   constructor(private page: Page) {
  10 |     this.headingText = page.locator("text=Think different. Make different");
  11 |     this.homeText = page.locator('#zak-primary-menu:has-text("Home")');
  12 |     this.searchIcon = page
  13 |       .locator(
  14 |         '//a[@class="zak-header-search__toggle"]//*[@class="zak-icon zakra-icon--magnifying-glass"]',
  15 |       )
  16 |       .first();
  17 |     this.navLinks = page.locator("#zak-primary-nav li[id*='menu-item']");
  18 |     this.getStartedBtn = page.locator("#get-started");
  19 |   }
  20 | 
  21 |   /**
  22 |    * Navigate page to baseUrl
  23 |    */
  24 |   async navigate() {
> 25 |     await this.page.goto("/");
     |                     ^ Error: page.goto: Protocol error (Page.navigate): Cannot navigate to invalid URL
  26 |   }
  27 | 
  28 |   /**
  29 |    *
  30 |    */
  31 |   getNavLiknsText() {
  32 |     return this.navLinks.allTextContents();
  33 |   }
  34 | }
  35 | 
  36 | export default HomePage;
  37 | 
```